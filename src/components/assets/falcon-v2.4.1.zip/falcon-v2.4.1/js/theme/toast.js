'use strict';

import utils from './Utils';

/*-----------------------------------------------
|   Toast [bootstrap 4]
-----------------------------------------------*/
utils.$document.ready(() => {
  $('.toast').toast();
});
