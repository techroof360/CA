/*-----------------------------------------------
|   Theme Configuration
-----------------------------------------------*/

const storage = {
  isDark: false
};

export default storage;
