#### Thank you for using Falcon.

For getting started, visit: https://prium.github.io/falcon/documentation/getting-started.html

Happy editing!
